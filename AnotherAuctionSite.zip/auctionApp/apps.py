from django.apps import AppConfig


class AunctionappConfig(AppConfig):
    name = 'auctionApp'
